return {
  "SORRYREWARD",
  "THEKRAKEN",
  "CARBON",
  "SORRYGUYS",
  "ATLANTEANSTORM",
  "GOLDENTIDE",
  "NewYear",
  "FISCHMASDAY",
  "NorthernExpedition",
  "MERRYFISCHMAS",
  "RFG"
}
