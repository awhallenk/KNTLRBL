loadstring(game:HttpGet("https://api.luarmor.net/files/v3/loaders/27394fa4dc9c7268a839f2c98b6a35f7.lua"))()
